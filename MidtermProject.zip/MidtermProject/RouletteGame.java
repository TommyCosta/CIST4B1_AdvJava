import java.util.Scanner;

public class RouletteGame {
    Scanner scanner = new Scanner(System.in);
    
	Wheel wheel = new Wheel();
    PayoutQueue queue = new PayoutQueue();
    TableBet betTable = new TableBet();
    DecisionTree decisionTree = new DecisionTree(scanner);
    SpinStack spinHistory = new SpinStack();
    int bankroll = 1000;
	
	public static void main(String[] args) {
		RouletteGame game = new RouletteGame();
		game.run();
	}

	public void run() {
		System.out.println("Welcome!");
		System.out.println("Good Luck!");
		System.out.println();
		System.out.println();
		
		while (true) {
            displayMenu();
            int input = getIntInput("Enter your choice: ");
            switch (input) {
                case 1:
                    placeBet();
                    break;
                case 2:
                    queue.listBets();
                    break;
                case 3:
                    spin();
                    break;
                case 4:
                    showBetInfo();
                    break;
                case 5:
                    spinHistory.displayHistory();
                    break;
                case 6:
                    exit();
                    break;
                default:
                    System.out.println("Invalid entry. Please enter a number 1-6.");
            }
        }	
	}
	
	public void displayMenu() {
		System.out.println("=============================");
		System.out.println("     ROULETTE SIMULATOR");
		System.out.println("=============================");
		System.out.println("  Bankroll: $" + bankroll);
		System.out.println("-----------------------------");
		System.out.println("  1. Place a Bet");
		System.out.println("  2. View Active Bets");
		System.out.println("  3. Spin the Wheel");
		System.out.println("  4. Bet Information");
		System.out.println("  5. Last 10 Spins");
		System.out.println("  6. Exit");
		System.out.println("=============================");
	}
	
	public void placeBet() {
		// check for $0 bankroll
		if (bankroll <= 0) {
			System.out.println("You are all out of money. Restart the game to make more bets.");
			return;
		}
		
		// traverse decisionTree to get bet type
		String betType = decisionTree.traverse();
		
		// get user input wager amount and validate it
		int wager = 0;
		while (wager <= 0 || wager > bankroll) {
			wager = getIntInput("How much would you like to wager? (Bankroll: $" + bankroll + "): ");
			if (wager <= 0) {
				System.out.println("Wager must be greater than $0. Please enter a different amount.");
			} else if (wager > bankroll) {
				System.out.println("Insufficient funds. Max wager: $" + bankroll + ". Please enter a different amount.");
			}
		}
		
		// create Bet subclass based on betType
		try {
            Bet bet = null;

            switch (betType) {
                case "COLOR":
                    System.out.println("Choose a color:");
                    System.out.println("1. Red");
                    System.out.println("2. Black");
                    int colorChoice = getIntInput("Enter your choice: ");
                    String color = (colorChoice == 1) ? "red" : "black";
                    bet = new BetColor(wager, color);
                    break;

                case "EVENODD":
                    System.out.println("Choose:");
                    System.out.println("1. Even");
                    System.out.println("2. Odd");
                    int parityChoice = getIntInput("Enter your choice: ");
                    String parity = (parityChoice == 1) ? "even" : "odd";
                    bet = new BetEvenOdd(wager, parity);
                    break;

                case "HIGHLOW":
                    System.out.println("Choose:");
                    System.out.println("1. Low (1-18)");
                    System.out.println("2. High (19-36)");
                    int hlChoice = getIntInput("Enter your choice: ");
                    String hiLo = (hlChoice == 1) ? "low" : "high";
                    bet = new BetHighLow(wager, hiLo);
                    break;

                case "DOZEN":
                    int dozen = getIntInput("Which dozen? (1 = 1-12, 2 = 13-24, 3 = 25-36): ");
                    bet = new BetDozen(wager, dozen);
                    break;

                case "COLUMN":
                    int column = getIntInput("Which column? (1, 2, or 3): ");
                    bet = new BetColumn(wager, column);
                    break;

                case "STRAIGHT":
                    System.out.println("Enter a number (0-36, or 37 for 00): ");
                    int number = getIntInput("Your number: ");
                    bet = new BetStraight(wager, number);
                    break;

             /* case "SPLIT":
                    System.out.println("Enter two adjacent numbers.");
                    int numA = getIntInput("First number: ");
                    int numB = getIntInput("Second number: ");
                    bet = new BetSplit(wager, numA, numB);
                    break;  */

             /* case "CORNER":
                    System.out.println("Enter four numbers forming a square on the board.");
                    int[] cornerNums = new int[4];
                    for (int i = 0; i < 4; i++) {
                        cornerNums[i] = getIntInput("Number " + (i + 1) + ": ");
                    }
                    bet = new BetCorner(wager, cornerNums);
                    break;  */

             /* case "STREET":
                    System.out.println("Enter three consecutive numbers in one row.");
                    int[] streetNums = new int[3];
                    for (int i = 0; i < 3; i++) {
                        streetNums[i] = getIntInput("Number " + (i + 1) + ": ");
                    }
                    bet = new BetStreet(wager, streetNums);
                    break;  */

                case "BASKET":
                    bet = new BetBasket(wager);
                    break;

             /* case "LINE":
                    System.out.println("Enter six numbers across two adjacent rows.");
                    int[] lineNums = new int[6];
                    for (int i = 0; i < 6; i++) {
                        lineNums[i] = getIntInput("Number " + (i + 1) + ": ");
                    }
                    bet = new BetLine(wager, lineNums);
                    break;

                default:
                    System.out.println("Unknown bet type. Returning to menu.");
                    return;  */
            } 
		
            // deduct wager amount from bankroll and enqueue the bet
            bankroll -= wager;
            queue.enqueue(bet);
            System.out.println("Bet placed! Remaining bankroll: $" + bankroll);
         
        // add error catch for bet constructor rejecting inputs    
		} catch (IllegalArgumentException e) {
            System.out.println("Invalid bet: " + e.getMessage());
            System.out.println("Returning to menu. No wager deducted.");
        }
	}
	
	public void spin() {
		// prevent spin if no bets have been placed
		if (queue.size == 0) {
			System.out.println("No bets placed! Please place a bet first.");
			return;
		}
		
		// spin wheel, record result, and add result to spin history stack
		WheelResult result = wheel.spin();
        spinHistory.push(result);

        System.out.println("\n  Spinning the wheel...");
        System.out.println("  Result: " + result.toString());
        System.out.println();
        
        // process payouts and update bankroll
        int net = processPayouts(result);
        bankroll  += net;

        System.out.println("-----------------------------");
        System.out.println("  Bankroll: $" + bankroll);
        System.out.println("-----------------------------");
	
        // check if player ran out of funds and offer to start over or exit
        if (bankroll <= 0) {
            System.out.println("You are out of funds! Game over.");
            int restartChoice = getIntInput("Would you like to restart with $1000?\n1. Yes\n2. No\nEnter your choice: ");
            if (restartChoice == 1) {
                bankroll = 1000;
                System.out.println("Bankroll reset to $1000. Good luck!");
            } else {
                exit();
            }
        }
	}
	
	public int processPayouts(WheelResult result) {
		int totalPayout = 0;
		int totalWagered = 0;
	    
		NodeBet temp = queue.head;
	    while (temp != null) {
	        totalWagered += temp.bet.wagerAmount;
	        temp = temp.right;
	    }
	    
		// traverse for, find, and display losing bets
		temp = queue.head;
		while (temp != null) {
			if (!temp.bet.isWinner(result)) {
		         System.out.println("  " + temp.bet.toString() + " is a loser. Your $" + temp.bet.wagerAmount + " wager is lost.");
		     }
		     temp = temp.right;
		}
		    
		// dequeue all bets, only displaying the winning bets
		while (queue.size != 0) {
	    NodeBet node = queue.dequeue();
	    if (node.bet.isWinner(result)) {
	    	System.out.println("  " + node.bet.toString() + " is a winner! You won $" + node.bet.calculatePayout() + "!");
	        totalPayout += node.bet.calculatePayout();
	        }
	    }   
		
		// display total profit/loss for the round 
		int roundResult = totalPayout - totalWagered;
		System.out.println();
		if (totalPayout == 0) {
	        System.out.println("  No winning bets this round.");
	        System.out.println("  Total Lost: $" + totalWagered);
	    } else if (roundResult == 0) {
	        System.out.println("  Total Returned: $" + totalPayout);
	        System.out.println("  You broke even this round.");
	    } else if (roundResult > 0) {
	        System.out.println("  Total Returned: $" + totalPayout);
	        System.out.println("  Net Profit: $" + roundResult);
	        System.out.println("  Congratulations!");
	    } else {
	        System.out.println("  Total Returned: $" + totalPayout);
	        System.out.println("  Net Loss: $" + (roundResult * -1));
	        System.out.println("  Better luck next time.");
	    }
		return totalPayout;
	}

	public void showBetInfo() {
		System.out.println("=============================");
		System.out.println("     Sort bets by:");
		System.out.println("     1. Best Odds");
		System.out.println("     2. Best Payout");
		System.out.println("     3. Back");
		System.out.println("=============================");
		
        int input = getIntInput("Enter your choice: ");
        switch (input) {
        case 1:
            betTable.sortByOdds();
            betTable.display();
            break;
        case 2:
            betTable.sortByPayout();
            betTable.display();
            break;
        case 3:
            return;
        default:
            System.out.println("Invalid entry. Returning to menu.");
		}
	}
	
	public void exit() {
		// display exit message and final total wins/losses
		System.out.println("Thanks for playing!");
		System.out.println("Final Bankroll: $" + bankroll);
		if (bankroll == 1000) {
			System.out.println("You broke even!");
		} else if (bankroll < 1000) {
			System.out.println("Better luck next time!");
		} else {
			System.out.println("You walked away as a winner!");
		}
		System.exit(0);
	}
	
	// helper function for validating inputs throughout this class
	public int getIntInput(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().strip());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

}